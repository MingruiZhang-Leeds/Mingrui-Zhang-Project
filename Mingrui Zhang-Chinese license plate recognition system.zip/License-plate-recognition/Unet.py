# -*- coding:utf-8 -*-

import numpy as np
import os
import cv2
from tensorflow.keras import layers, losses, models

def check_path_exists(file_path):
    if not os.path.exists(file_path):
        print(f"Error: Path does not exist - {file_path}")
        return False
    return True

def unet_train():

    height = 512
    width = 512
    base_path = '//U-net_datasets/'
    train_image_path = os.path.join(base_path, 'train_image')
    train_label_path = os.path.join(base_path, 'train_label')
    if not check_path_exists(train_image_path):
        return
    if not check_path_exists(train_label_path):
        return
    input_name = os.listdir(train_image_path)
    n = len(input_name)
    print(f"Number of images found: {n}")

    X_train, y_train = [], []
    for img_name in input_name:
        img_path = os.path.join(train_image_path, img_name)
        label_name = img_name.replace('train_image', 'train_label')
        label_path = os.path.join(train_label_path, label_name)


        print(f"Reading image: {img_path}")
        print(f"Reading label: {label_path}")


        img_path = os.path.abspath(img_path)
        label_path = os.path.abspath(label_path)

        img = cv2.imdecode(np.fromfile(img_path, dtype=np.uint8), -1)
        label = cv2.imdecode(np.fromfile(label_path, dtype=np.uint8), -1)

        if img is None:
            print(f"Warning: Failed to read image {img_path}. Skipping this file.")
            continue
        if label is None:
            print(f"Warning: Failed to read label {label_path}. Skipping this file.")
            continue


        if label.ndim == 2:
            label = cv2.cvtColor(label, cv2.COLOR_GRAY2RGB)

        X_train.append(img)
        y_train.append(label)

    X_train = np.array(X_train)
    y_train = np.array(y_train)

    if len(X_train) == 0 or len(y_train) == 0:
        raise ValueError("No valid images or labels found. Please check your dataset.")

    def Conv2d_BN(x, nb_filter, kernel_size, strides=(1, 1), padding='same'):
        x = layers.Conv2D(nb_filter, kernel_size, strides=strides, padding=padding)(x)
        x = layers.BatchNormalization(axis=3)(x)
        x = layers.LeakyReLU(alpha=0.1)(x)
        return x

    def Conv2dT_BN(x, filters, kernel_size, strides=(2, 2), padding='same'):
        x = layers.Conv2DTranspose(filters, kernel_size, strides=strides, padding=padding)(x)
        x = layers.BatchNormalization(axis=3)(x)
        x = layers.LeakyReLU(alpha=0.1)(x)
        return x

    inpt = layers.Input(shape=(height, width, 3))
    conv1 = Conv2d_BN(inpt, 8, (3, 3))
    conv1 = Conv2d_BN(conv1, 8, (3, 3))
    pool1 = layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same')(conv1)

    conv2 = Conv2d_BN(pool1, 16, (3, 3))
    conv2 = Conv2d_BN(conv2, 16, (3, 3))
    pool2 = layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same')(conv2)

    conv3 = Conv2d_BN(pool2, 32, (3, 3))
    conv3 = Conv2d_BN(conv3, 32, (3, 3))
    pool3 = layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same')(conv3)

    conv4 = Conv2d_BN(pool3, 64, (3, 3))
    conv4 = Conv2d_BN(conv4, 64, (3, 3))
    pool4 = layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same')(conv4)

    conv5 = Conv2d_BN(pool4, 128, (3, 3))
    conv5 = layers.Dropout(0.5)(conv5)
    conv5 = Conv2d_BN(conv5, 128, (3, 3))
    conv5 = layers.Dropout(0.5)(conv5)

    convt1 = Conv2dT_BN(conv5, 64, (3, 3))
    concat1 = layers.concatenate([conv4, convt1], axis=3)
    concat1 = layers.Dropout(0.5)(concat1)
    conv6 = Conv2d_BN(concat1, 64, (3, 3))
    conv6 = Conv2d_BN(conv6, 64, (3, 3))

    convt2 = Conv2dT_BN(conv6, 32, (3, 3))
    concat2 = layers.concatenate([conv3, convt2], axis=3)
    concat2 = layers.Dropout(0.5)(concat2)
    conv7 = Conv2d_BN(concat2, 32, (3, 3))
    conv7 = Conv2d_BN(conv7, 32, (3, 3))

    convt3 = Conv2dT_BN(conv7, 16, (3, 3))
    concat3 = layers.concatenate([conv2, convt3], axis=3)
    concat3 = layers.Dropout(0.5)(concat3)
    conv8 = Conv2d_BN(concat3, 16, (3, 3))
    conv8 = Conv2d_BN(conv8, 16, (3, 3))

    convt4 = Conv2dT_BN(conv8, 8, (3, 3))
    concat4 = layers.concatenate([conv1, convt4], axis=3)
    concat4 = layers.Dropout(0.5)(concat4)
    conv9 = Conv2d_BN(concat4, 8, (3, 3))
    conv9 = Conv2d_BN(conv9, 8, (3, 3))
    conv9 = layers.Dropout(0.5)(conv9)
    outpt = layers.Conv2D(filters=3, kernel_size=(1, 1), strides=(1, 1), padding='same', activation='relu')(conv9)

    model = models.Model(inpt, outpt)
    model.compile(optimizer='adam', loss='mean_squared_error', metrics=['accuracy'])
    model.summary()

    print("start training u-net")
    model.fit(X_train, y_train, epochs=100, batch_size=15)
    model.save('unet.h5')
    print('unet.h5 save !!!')

unet_train()
