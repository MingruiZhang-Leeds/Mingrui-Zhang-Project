from CNN import cnn_train
cnn_train()