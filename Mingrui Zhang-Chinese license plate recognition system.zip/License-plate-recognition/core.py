# -*- coding:utf-8 -*-

import cv2
import numpy as np
import os

from tensorflow import keras
# from tensorflow.Lib.pydoc import locate



# from Unet import unet_predict




# u-net
def unet_predict(unet, img_src_path):
    img_src = cv2.imdecode(np.fromfile(img_src_path, dtype=np.uint8), -1)
    # img_src=cv2.imread(img_src_path)
    if img_src.shape != (512, 512, 3):

        img_src = cv2.resize(img_src, dsize=(512, 512), interpolation=cv2.INTER_AREA)[:, :, :3]
    img_src = img_src.reshape(1, 512, 512, 3)

    img_mask = unet.predict(img_src)
    img_src = img_src.reshape(512, 512, 3)
    img_mask = img_mask.reshape(512, 512, 3)
    img_mask = img_mask / np.max(img_mask) * 255
    img_mask[:, :, 2] = img_mask[:, :, 1] = img_mask[:, :, 0]
    img_mask = img_mask.astype(np.uint8)

    return img_src, img_mask



#
def locate_and_correct(img_src, img_mask):
    """

    """
    # print('img_src.shape', img_src.shape)

    # cv2.imshow('img_mask',img_mask)
    # cv2.waitKey(0)
    # ret,thresh = cv2.threshold(img_mask[:,:,0],0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU) #二值化操作

    # cv2.imshow('thresh',thresh)
    # cv2.waitKey(0)
    # print('img_mask.shape', img_mask.shape)
    # img_mask = cv2.cvtColor(img_mask, cv2.COLOR_BGR2GRAY)

    try:  # try...except
        contours, hierarchy = cv2.findContours(img_mask[:, :, 0], cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    except:
        ret, contours, hierarchy = cv2.findContours(img_mask[:, :, 0], cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if not len(contours):
        # print("nothing")
        return [], []
    else:
        Lic_img = []
        img_src_copy = img_src.copy()  # img_src_copy
        for ii, cont in enumerate(contours):
            x, y, w, h = cv2.boundingRect(cont)  #
            img_cut_mask = img_mask[y:y + h, x:x + w]  #
            # cv2.imshow('img_cut_mask',img_cut_mask)    #
            # cv2.waitKey(0)     #
            # print('w,h,',w,h,np.mean(img_cut_mask),w/h)

            # contours
            #
            if np.mean(img_cut_mask) >= 75 and w > 15 and h > 15:  #
                rect = cv2.minAreaRect(cont)
                box = cv2.boxPoints(rect).astype(np.int32)
                # cv2.drawContours(img_mask, contours, -1, (0, 0, 255), 2)
                # cv2.drawContours(img_mask, [box], 0, (0, 255, 0), 2)
                # cv2.imshow('img_mask1',img_mask)
                # cv2.waitKey(0)
                cont = cont.reshape(-1, 2).tolist()

                box = sorted(box, key=lambda xy: xy[0])
                box_left, box_right = box[:2], box[2:]
                box_left = sorted(box_left, key=lambda x: x[1])
                box_right = sorted(box_right, key=lambda x: x[1])
                box = np.array(box_left + box_right)
                # print(box)
                x0, y0 = box[0][0], box[0][1]
                x1, y1 = box[1][0], box[1][1]
                x2, y2 = box[2][0], box[2][1]
                x3, y3 = box[3][0], box[3][1]


                def point_to_line_distance(X, Y):
                    if x2 - x0:
                        k_up = (y2 - y0) / (x2 - x0)
                        d_up = abs(k_up * X - Y + y2 - k_up * x2) / (k_up ** 2 + 1) ** 0.5
                    else:
                        d_up = abs(X - x2)
                    if x1 - x3:
                        k_down = (y1 - y3) / (x1 - x3)
                        d_down = abs(k_down * X - Y + y1 - k_down * x1) / (k_down ** 2 + 1) ** 0.5
                    else:
                        d_down = abs(X - x1)
                    return d_up, d_down

                d0, d1, d2, d3 = np.inf, np.inf, np.inf, np.inf
                l0, l1, l2, l3 = (x0, y0), (x1, y1), (x2, y2), (x3, y3)

                for each in cont:
                    x, y = each[0], each[1]
                    dis0 = (x - x0) ** 2 + (y - y0) ** 2
                    dis1 = (x - x1) ** 2 + (y - y1) ** 2
                    dis2 = (x - x2) ** 2 + (y - y2) ** 2
                    dis3 = (x - x3) ** 2 + (y - y3) ** 2
                    d_up, d_down = point_to_line_distance(x, y)
                    weight = 0.975
                    if weight * d_up + (1 - weight) * dis0 < d0:
                        d0 = weight * d_up + (1 - weight) * dis0
                        l0 = (x, y)
                    if weight * d_down + (1 - weight) * dis1 < d1:
                        d1 = weight * d_down + (1 - weight) * dis1
                        l1 = (x, y)
                    if weight * d_up + (1 - weight) * dis2 < d2:
                        d2 = weight * d_up + (1 - weight) * dis2
                        l2 = (x, y)
                    if weight * d_down + (1 - weight) * dis3 < d3:
                        d3 = weight * d_down + (1 - weight) * dis3
                        l3 = (x, y)

                # print([l0,l1,l2,l3])
                # for l in [l0, l1, l2, l3]:
                #     cv2.circle(img=img_mask, color=(0, 255, 255), center=tuple(l), thickness=2, radius=2)
                # cv2.imshow('img_mask2',img_mask)
                # cv2.waitKey(0)
                p0 = np.float32([l0, l1, l2, l3])
                p1 = np.float32([(0, 0), (0, 80), (240, 0), (240, 80)])
                transform_mat = cv2.getPerspectiveTransform(p0, p1)
                lic = cv2.warpPerspective(img_src, transform_mat, (240, 80))
                # cv2.imshow('lic',lic)
                # cv2.waitKey(0)


                Lic_img.append(lic)

                cv2.drawContours(img_src_copy, [np.array([l0, l1, l3, l2])], -1, (0, 255, 0), 2)
    return img_src_copy, Lic_img




