import cv2
import numpy as np
def detect_license_plate(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edged = cv2.Canny(gray, 50, 150)
    contours, _ = cv2.findContours(edged, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]
    for c in contours:
        rect = cv2.minAreaRect(c)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        width, height = rect[1]

        if width < height:
            width, height = height, width
        aspect_ratio = width / height
        if 2 < aspect_ratio < 6:
            cv2.drawContours(image, [box], -1, (0, 255, 0), 3)
            return image
    return image



image_path = 'test_image.jpg'
image = cv2.imread(image_path)
result = detect_license_plate(image)
cv2.imshow('Detected License Plate', result)
cv2.waitKey(0)
cv2.destroyAllWindows()
