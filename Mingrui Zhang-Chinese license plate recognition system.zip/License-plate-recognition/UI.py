# -*- coding:utf-8 -*-

import sys
import cv2
import numpy as np
from tkinter import *
from tkinter.filedialog import askopenfilename
from PIL import Image, ImageTk
from tensorflow import keras

from core import locate_and_correct
# from Unet import unet_predict
from core import unet_predict
from CNN import cnn_predict

from tkinter import Tk
from  tkinter import messagebox


class Window:

    def __init__(self, win, ww, wh):
        self.win = win
        self.ww = ww
        self.wh = wh
        self.win.geometry("%dx%d+%d+%d" % (ww, wh, 150, 50))
        self.win.title("License Plate Recognition Based on CNN Digital Network")
        self.img_src_path = None

        self.label_src = Label(self.win, text='Original image:', font=('微软雅黑', 8)).place(x=0, y=0)
        self.label_lic1 = Label(self.win, text='License Plate Area 1:', font=('微软雅黑', 8)).place(x=600, y=50)
        self.label_pred1 = Label(self.win, text='Recognition result 1:', font=('微软雅黑', 8)).place(x=600, y=150)
        self.label_lic2 = Label(self.win, text='License Plate Area 2:', font=('微软雅黑', 8)).place(x=600, y=300)
        self.label_pred2 = Label(self.win, text='Recognition result 2:', font=('微软雅黑', 8)).place(x=600, y=400)

        self.can_src = Canvas(self.win, width=512, height=512, bg='white', relief='solid', borderwidth=1)
        self.can_src.place(x=50, y=20)
        self.can_lic1 = Canvas(self.win, width=260, height=90, bg='white', relief='solid', borderwidth=1)
        self.can_lic1.place(x=710, y=20)
        self.can_pred1 = Canvas(self.win, width=260, height=90, bg='white', relief='solid', borderwidth=1)
        self.can_pred1.place(x=710, y=120)
        self.can_lic2 = Canvas(self.win, width=260, height=90, bg='white', relief='solid', borderwidth=1)
        self.can_lic2.place(x=710, y=270)
        self.can_pred2 = Canvas(self.win, width=260, height=90, bg='white', relief='solid', borderwidth=1)
        self.can_pred2.place(x=710, y=370)

        self.button1 = Button(self.win, text='Select', width=10, height=1, command=self.load_show_img)
        self.button1.place(x=680, y=wh - 50)
        self.button2 = Button(self.win, text='Recognition', width=10, height=1, command=self.display)
        self.button2.place(x=780, y=wh - 50)
        self.button3 = Button(self.win, text='Clear', width=10, height=1, command=self.clear)
        self.button3.place(x=880, y=wh - 50)
        self.unet = keras.models.load_model('unet.h5')
        self.cnn = keras.models.load_model('cnn.h5')
        print('Starting, please wait.....')
        cnn_predict(self.cnn, [np.zeros((80, 240, 3))])
        print("Started, ready to start recognizing!")


    def load_show_img(self):
        self.clear()
        sv = StringVar()
        sv.set(askopenfilename())
        self.img_src_path = Entry(self.win, state='readonly', text=sv).get()
        img_open = Image.open(self.img_src_path)
        if img_open.size[0] * img_open.size[1] > 240 * 80:
            img_open = img_open.resize((512, 512), Image.ANTIALIAS)
        self.img_Tk = ImageTk.PhotoImage(img_open)
        self.can_src.create_image(258, 258, image=self.img_Tk, anchor='center')

    def display(self):
        if self.img_src_path == None:
            self.can_pred1.create_text(32, 15, text='Please select a picture', anchor='nw', font=('黑体', 6))  # anchor    font
        else:
            img_src = cv2.imdecode(np.fromfile(self.img_src_path, dtype=np.uint8), -1)
            h, w = img_src.shape[0], img_src.shape[1]
            if h * w <= 240 * 80 and 2 <= w / h <= 5:
                lic = cv2.resize(img_src, dsize=(240, 80), interpolation=cv2.INTER_AREA)[:, :, :3]
                img_src_copy, Lic_img = img_src, [lic]
            else:
                img_src, img_mask = unet_predict(self.unet, self.img_src_path)
                img_src_copy, Lic_img = locate_and_correct(img_src, img_mask)

            Lic_pred = cnn_predict(self.cnn, Lic_img)
            if Lic_pred:
                img = Image.fromarray(img_src_copy[:, :, ::-1])
                self.img_Tk = ImageTk.PhotoImage(img)
                self.can_src.delete('all')
                self.can_src.create_image(258, 258, image=self.img_Tk,
                                          anchor='center')
                for i, lic_pred in enumerate(Lic_pred):
                    if i == 0:
                        self.lic_Tk1 = ImageTk.PhotoImage(Image.fromarray(lic_pred[0][:, :, ::-1]))
                        self.can_lic1.create_image(5, 5, image=self.lic_Tk1, anchor='nw')
                        self.can_pred1.create_text(35, 15, text=lic_pred[1], anchor='nw', font=('黑体', 26))
                    elif i == 1:
                        self.lic_Tk2 = ImageTk.PhotoImage(Image.fromarray(lic_pred[0][:, :, ::-1]))
                        self.can_lic2.create_image(5, 5, image=self.lic_Tk2, anchor='nw')
                        self.can_pred2.create_text(40, 15, text=lic_pred[1], anchor='nw', font=('黑体', 26))


            else:  # Lic_pred
                self.can_pred1.create_text(47, 15, text='Unable to identify', anchor='nw', font=('黑体', 15))

    def clear(self):
        self.can_src.delete('all')

        self.can_lic1.delete('all')
        self.can_lic2.delete('all')

        self.can_pred1.delete('all')
        self.can_pred2.delete('all')
        self.img_src_path = None

    # 最初的
    # def closeEvent(self):  # 'NoneType' object is not callable
    #     keras.backend.clear_session()   # clear_session
    #     sys.exit()


    # def closeEvent(self):
    #     if messagebox.askokcancel('Quit'):
    #         win.destroy()

    # def main(self):
    #     root = Tk()
    #     b = Button(root, test='退出', command=root.quit)
    #     b.pack()
    #     mainloop()

if __name__ == '__main__':
    win = Tk()
    ww = 1000
    wh = 600
    Window(win, ww, wh)
    # win.protocol("WM_DELETE_WINDOW",Window.closeEvent)
    cv2.destroyAllWindows()
    win.mainloop()

